var searchData=
[
  ['chef_0',['Chef',['../class_chef.html',1,'']]],
  ['customer_1',['Customer',['../class_customer.html',1,'']]]
];

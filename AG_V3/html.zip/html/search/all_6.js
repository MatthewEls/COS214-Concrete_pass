var searchData=
[
  ['headchef_0',['headchef',['../class_head_chef.html',1,'HeadChef'],['../class_head_chef.html#a8caff092ea8227b43657506ff1cb6efe',1,'HeadChef::HeadChef()']]]
];

var searchData=
[
  ['headchef_0',['HeadChef',['../class_head_chef.html#a8caff092ea8227b43657506ff1cb6efe',1,'HeadChef']]]
];

var searchData=
[
  ['souschef_0',['SousChef',['../class_sous_chef.html',1,'']]]
];

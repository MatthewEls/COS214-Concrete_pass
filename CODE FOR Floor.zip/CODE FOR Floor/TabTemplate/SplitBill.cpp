#include "SplitBill.h"

double SplitBill::calculateTotal(double subtotal, double out)
{
    return subtotal * 1.1;
}

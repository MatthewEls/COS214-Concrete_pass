#include "OneBill.h"

double OneBill::calculateTotal(double subtotal, double out)
{
    return subtotal * 1.1; 
}
